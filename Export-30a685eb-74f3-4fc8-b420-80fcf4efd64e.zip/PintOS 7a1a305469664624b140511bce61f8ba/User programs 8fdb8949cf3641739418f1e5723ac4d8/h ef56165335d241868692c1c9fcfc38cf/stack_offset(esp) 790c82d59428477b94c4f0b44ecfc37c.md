# stack_offset(esp)

Descripción: Retorna el offset necesario para sumarselo a la página devuelta por pagedir_get_page()  esp es la dirección falsa que tiene el usuario sobre el stack
Tags: function, macro