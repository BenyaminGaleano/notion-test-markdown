# stkcast(pointer, type)

Descripción: retorna un valor del tipo type desde pointer, prácticamente es una forma más entendible que colocar *((type *) pointer) ya que en muchos casos esta expresión crece mucho y suele ser un poco inentendible
Tags: function, macro