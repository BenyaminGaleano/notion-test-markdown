# put_user(udst, byte)

Descripción: intenta escribir en la dirección de destino, true si es posible y false si no.
Tags: function