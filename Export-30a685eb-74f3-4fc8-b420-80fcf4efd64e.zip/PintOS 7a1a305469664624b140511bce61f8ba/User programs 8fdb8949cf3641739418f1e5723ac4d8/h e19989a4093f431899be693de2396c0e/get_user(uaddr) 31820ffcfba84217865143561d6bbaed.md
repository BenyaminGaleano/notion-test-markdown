# get_user(uaddr)

Descripción: lee un byte en la dirección y lo devuelve, sino es posible retorna -1 
Tags: function