# sys_closef

Descripción: cierra un archivo pero requiriendo el lock del filesys
Tags: function