# fsys_unlock

Descripción: libera al filesys
Tags: function