# thread_create

Descripción: se modificó para poder agregar al padre una página para rastrear su hijos y registrarse en ese espacio
Tags: function