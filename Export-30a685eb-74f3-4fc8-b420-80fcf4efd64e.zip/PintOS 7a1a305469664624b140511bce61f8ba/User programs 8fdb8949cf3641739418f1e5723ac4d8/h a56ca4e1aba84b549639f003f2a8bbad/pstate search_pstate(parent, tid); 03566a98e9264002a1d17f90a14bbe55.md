# pstate *search_pstate(parent, tid);

Descripción: Al ser dados un puntero hacia el padre y un id del hijo que se desea rastrear, esta función es capaz de entregar el estado del proceso hijo
Tags: function