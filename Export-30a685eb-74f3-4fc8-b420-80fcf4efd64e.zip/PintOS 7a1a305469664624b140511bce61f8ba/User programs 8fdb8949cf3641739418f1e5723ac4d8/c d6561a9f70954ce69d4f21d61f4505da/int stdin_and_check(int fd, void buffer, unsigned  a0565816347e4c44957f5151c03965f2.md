# int stdin_and_check(int fd, void *buffer, unsigned length);

Descripción: chequea buffer y también si es stdin, si se lee se devuelve la cantidad de bytes leidos, sino -1 diciendo que se ha comprobado todo, pero que no se ha leido
Tags: function