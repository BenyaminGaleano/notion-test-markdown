# void checkbytes(pointer, n);

Descripción: chequea n bytes de pointer
Tags: function