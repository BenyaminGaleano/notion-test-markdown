# write(fd, buffer, n)

Descripción: escribe n bytes del buffer al archivo
Tags: function