# struct lock filesys_lock;

Descripción: lock del filesys global
Tags: function