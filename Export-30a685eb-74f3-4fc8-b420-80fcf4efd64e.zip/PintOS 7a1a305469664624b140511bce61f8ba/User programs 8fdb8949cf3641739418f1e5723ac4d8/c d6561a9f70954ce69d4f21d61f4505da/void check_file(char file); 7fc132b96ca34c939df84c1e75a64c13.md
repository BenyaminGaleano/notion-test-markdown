# void check_file(char *file);

Descripción: chequea que los bytes del nombre del archivo (file es el nombre) sean válidos
Tags: function