# exit(status)

Descripción: sale del proceso preparando las variables necesarias para process_exit
Tags: function