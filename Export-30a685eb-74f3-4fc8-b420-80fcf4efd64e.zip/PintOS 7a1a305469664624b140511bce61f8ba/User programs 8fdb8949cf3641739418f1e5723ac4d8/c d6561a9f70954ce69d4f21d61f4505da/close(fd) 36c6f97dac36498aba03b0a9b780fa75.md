# close(fd)

Descripción: cierra el archivo y lo elimina de files
Tags: function