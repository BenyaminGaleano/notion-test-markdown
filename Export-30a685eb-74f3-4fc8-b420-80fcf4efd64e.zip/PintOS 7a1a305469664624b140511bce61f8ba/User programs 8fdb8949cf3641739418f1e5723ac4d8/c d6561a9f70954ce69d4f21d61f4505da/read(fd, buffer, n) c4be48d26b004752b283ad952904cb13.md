# read(fd, buffer, n)

Descripción: lee n bytes del archivo y lo mete en buffer
Tags: function