# seek(fd, position)

Descripción: cambia el puntero al siguiente byte hacia position
Tags: function