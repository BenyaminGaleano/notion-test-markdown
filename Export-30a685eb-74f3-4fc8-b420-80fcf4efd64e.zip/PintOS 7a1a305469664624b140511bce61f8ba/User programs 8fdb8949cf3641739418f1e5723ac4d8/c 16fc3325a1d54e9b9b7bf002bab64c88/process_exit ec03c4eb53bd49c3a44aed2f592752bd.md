# process_exit

Descripción: se liberan todos los recursos del proceso, se cambia el estado del proceso en el tracking del padre
Tags: function