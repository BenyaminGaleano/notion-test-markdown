# process_execute

Descripción: Se tokeniza el nombre para mandarselo al thread_create
Tags: function