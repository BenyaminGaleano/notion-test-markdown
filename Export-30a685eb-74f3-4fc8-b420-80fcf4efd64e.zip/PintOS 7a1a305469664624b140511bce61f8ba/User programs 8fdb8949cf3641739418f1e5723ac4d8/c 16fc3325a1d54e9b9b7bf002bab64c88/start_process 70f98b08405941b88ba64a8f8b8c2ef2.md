# start_process

Descripción: tokenizar el comand y alocar los valores en el stack del proceso, notificación del padre cuándo se ha terminado la creación, pide memoria para seguimiento de archivos
Tags: function