# update_priority(struct thread *t, void *aux)

Descripción: actualiza la prioridad de un thread, ignorando la solicitud si se trata del idle_thread
Tags: función, void