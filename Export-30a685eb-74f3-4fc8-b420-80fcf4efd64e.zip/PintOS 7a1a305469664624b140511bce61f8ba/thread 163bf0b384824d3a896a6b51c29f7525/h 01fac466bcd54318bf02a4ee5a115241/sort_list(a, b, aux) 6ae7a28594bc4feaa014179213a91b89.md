# sort_list(a, b, aux)

Descripción: Compara las prioridades de los threads a y b.
Tags: bool, función