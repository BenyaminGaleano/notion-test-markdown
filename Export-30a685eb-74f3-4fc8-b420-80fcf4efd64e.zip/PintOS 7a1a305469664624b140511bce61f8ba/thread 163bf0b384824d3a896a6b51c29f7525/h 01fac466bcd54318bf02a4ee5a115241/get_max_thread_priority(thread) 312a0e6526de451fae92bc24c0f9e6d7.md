# get_max_thread_priority(thread)

Descripción: Revisa la lista de locks para ver si se cambia su prioridad por donación.
Tags: función, void