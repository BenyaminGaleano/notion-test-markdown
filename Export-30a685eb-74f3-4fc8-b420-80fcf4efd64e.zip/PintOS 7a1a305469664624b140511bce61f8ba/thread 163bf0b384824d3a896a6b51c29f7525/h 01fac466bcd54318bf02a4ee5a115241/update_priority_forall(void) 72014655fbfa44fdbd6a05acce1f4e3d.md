# update_priority_forall(void)

Descripción: actualiza la prioridad de todos los threads, evitando el idle_thread. Esta función es llamada cada 4 ticks que el reloj marca
Tags: función, void