# propage_priority(thred)

Descripción: propaga la prioridad de thread hacia el que lo bloquea de forma recursiva, es decir se vuelve a llamar asi mismo para que la propagación hacia adelante se complete.
Tags: función, void