# increment_recent_cpu(void)

Descripción: incrementa el recent_cpu del thread actual.
Tags: función, void