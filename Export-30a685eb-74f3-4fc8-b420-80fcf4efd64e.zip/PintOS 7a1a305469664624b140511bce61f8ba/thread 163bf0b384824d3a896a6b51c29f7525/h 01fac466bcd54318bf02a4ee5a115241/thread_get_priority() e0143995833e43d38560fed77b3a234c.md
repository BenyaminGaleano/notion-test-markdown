# thread_get_priority()

Descripción: Devuelve la prioridad del thread actual.
Tags: función, int