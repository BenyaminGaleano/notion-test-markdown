# sort_list_by_priority()

Descripción: Ordena la lista de threads por la prioridad (tomando en cuenta si tuvo donaciones de prioridad por locks) .
Tags: función, void