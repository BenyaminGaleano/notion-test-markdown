# thread_set_priority(new_priority)

Descripción: Modifica la prioridad del thread a new_priority.
Tags: función, void