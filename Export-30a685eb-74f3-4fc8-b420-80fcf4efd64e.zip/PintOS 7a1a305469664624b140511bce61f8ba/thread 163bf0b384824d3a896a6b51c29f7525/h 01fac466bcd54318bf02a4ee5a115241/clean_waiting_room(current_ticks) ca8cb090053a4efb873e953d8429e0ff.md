# clean_waiting_room(current_ticks)

Descripción: Quita de la lista todos los threads que han expirado su tiempo de espera.
Tags: función, void