# update_recent_cpu(void)

Descripción: actualiza el recent_cpu de todos los threads activos, por lo que itera sobre all_list definida en threads. se llama cada segundo
Tags: función, void