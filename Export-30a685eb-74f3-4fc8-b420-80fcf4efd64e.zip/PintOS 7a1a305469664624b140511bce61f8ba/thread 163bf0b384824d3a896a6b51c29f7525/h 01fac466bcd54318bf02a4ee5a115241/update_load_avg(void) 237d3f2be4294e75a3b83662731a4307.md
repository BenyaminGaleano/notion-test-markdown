# update_load_avg(void)

Descripción: actualiza el load_avg que se encuentra defina de thread.c, conforme lo marca la formula. es llamada desde timer.c cada 1 segundo.
Tags: función, void