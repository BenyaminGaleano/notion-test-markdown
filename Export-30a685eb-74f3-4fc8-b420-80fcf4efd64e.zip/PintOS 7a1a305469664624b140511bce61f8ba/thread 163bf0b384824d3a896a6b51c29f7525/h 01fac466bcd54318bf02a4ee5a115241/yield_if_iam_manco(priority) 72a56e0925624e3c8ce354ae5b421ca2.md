# yield_if_iam_manco(priority)

Descripción: cede el procesador si priority es mayor que la prioridad del current thread, funciona tanto como para MLFQS como para el PS
Tags: función, void