# to_waiting_room(ticks)

Descripción: Manda al thread actual a la lista de espera.
Tags: función, void