# semaphore_elem

Descripción: Se le agregó un puntero al thread que se enlaza (para poder reordenarlos para las varcond)
Tags: struct