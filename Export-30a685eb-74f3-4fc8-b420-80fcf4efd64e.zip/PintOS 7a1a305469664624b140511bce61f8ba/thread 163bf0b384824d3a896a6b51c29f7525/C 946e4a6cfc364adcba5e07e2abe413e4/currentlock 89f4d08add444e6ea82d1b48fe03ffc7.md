# currentlock

Descripción: un puntero hacia el lock actual
Tags: lock, struct, variable