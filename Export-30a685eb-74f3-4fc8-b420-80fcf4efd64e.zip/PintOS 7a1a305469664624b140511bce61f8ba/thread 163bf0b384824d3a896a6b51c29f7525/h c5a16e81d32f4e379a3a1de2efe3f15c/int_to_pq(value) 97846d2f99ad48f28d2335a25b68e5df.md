# int_to_pq(value)

Descripción: toma un entero de 32 bits para convertirlo a la notación pq (17.14 para nosotros) 
Tags: función, macro, pq1714