# pq_div(pq1, pq2)

Descripción: toma 2 números pseudo reales y los divide, no valida excepciones de división por 0 o cosas así.
Tags: función, macro, pq1714