# sort_sema_items

Descripción: es un comparator para reordenar los items de una lista de semaphore_elem por medio de la prioridad del thread que contiene
Tags: bool, function