# waiting_room

Descripción: Donde se en colan los threads que se quedan esperando por cierto tiempo
Tags: list, variable