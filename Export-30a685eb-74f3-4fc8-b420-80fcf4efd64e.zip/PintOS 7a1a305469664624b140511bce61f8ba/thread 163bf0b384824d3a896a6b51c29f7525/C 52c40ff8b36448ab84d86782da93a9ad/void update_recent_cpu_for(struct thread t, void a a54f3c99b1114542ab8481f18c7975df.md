# void update_recent_cpu_for(struct thread *t, void *aux UNUSED)

Descripción: actualiza recent_cpu según lo estipulado en la documentación de pintos, es ignorada la petición si se trata de idle_thread
Tags: función, void